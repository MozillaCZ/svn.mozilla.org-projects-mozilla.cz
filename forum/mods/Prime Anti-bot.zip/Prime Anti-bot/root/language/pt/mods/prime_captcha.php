<?php
/**
*
* prime_captcha [Portuguese]
*
* @package language
* @version $Id: prime_captcha.php,v 1.0.4 2008/08/27 13:34:00 primehalo Exp $
* @copyright (c) 2007 Ken F. Innes IV
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(
	// ACP
	'PRIME_CAPTCHA_POST'			=> 'Texto verificação de colocação de mensagens por visitantes',
	'PRIME_CAPTCHA_POST_EXPLAIN'	=> 'Obriga a que utilizadores anónimos respondam correctamente a uma pergunta ou instrução.',
	'PRIME_CAPTCHA_REG'				=> 'Texto verificação para registos',
	'PRIME_CAPTCHA_REG_EXPLAIN'		=> 'Obriga a que novos utilizadores respondam correctamente a uma pergunta ou instrução para prevenir registos em massa.',
	'PRIME_CAPTCHA_ENABLE'			=> 'Activar',
	'PRIME_CAPTCHA_TEMPLATE'		=> 'Numa página separada',
	'PRIME_CAPTCHA_DISABLE'			=> 'Desactivar',

	// General
	'PRIME_CAPTCHA_MOD_NAME'		=> 'Prime CAPTCHA',
	'PRIME_CAPTCHA_TITLE'   		=> 'Sistema de verificação de humanos',
	'PRIME_CAPTCHA_DESCRIPTION' 	=> 'Previne robots automatizados de SPAM de enviar formulários.',
	'PRIME_CAPTCHA_INSTRUCTIONS' 	=> 'Responda correctamente para confirmar que é humano.',
	'PRIME_CAPTCHA_INCORRECT'  		=> 'A resposta de verificação de humano está incorrecta.',
	'PRIME_CAPTCHA_EMPTY'	  		=> 'Não introduziu a resposta de verificação de humano.',
	'PRIME_CAPTCHA_NO_KEY'	  		=> 'Não existe nenhuma chave de verificação de humano, o que indica que é uma submissão de um robot.',
	'PRIME_CAPTCHA_SUBMIT'  		=> 'Enviar Resposta',
));

?>